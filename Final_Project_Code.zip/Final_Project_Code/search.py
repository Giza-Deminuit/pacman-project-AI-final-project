# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

import util

class SearchProblem:

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfacts(self, acts):
        """
         acts: A list of acts to take

        This method returns the total cost of a particular sequence of acts.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    south = Directions.SOUTH
    west = Directions.WEST
    return  [south, south, west, south, west, west, south, west]

def depthFirstSearch(problem):
    startNode = problem.getStartState()
    if problem.isGoalState(startNode): return []

    queue = util.Stack()
    node_Visited = []
    queue.push((startNode, []))

    while not queue.isEmpty():
        node_Current, acts = queue.pop()
        if node_Current not in node_Visited:
            node_Visited.append(node_Current)

            if problem.isGoalState(node_Current):
                return acts

            for nextNode, action, cost in problem.getSuccessors(node_Current):
                newAction = acts + [action]
                queue.push((nextNode, newAction))

def breadthFirstSearch(problem):
    node_Start = problem.getStartState()
    if problem.isGoalState(node_Start): return []

    queue = util.Queue()
    node_Visited = []
    queue.push((node_Start, []))

    while not queue.isEmpty():
        node_Current, acts = queue.pop()
        if node_Current not in node_Visited:
            node_Visited.append(node_Current)

            if problem.isGoalState(node_Current): return acts

            for nextNode, action, cost in problem.getSuccessors(node_Current):
                newAction = acts + [action]
                queue.push((nextNode, newAction))

    util.raiseNotDefined()

def uniformCostSearch(problem):
    node_Start = problem.getStartState()
    if problem.isGoalState(node_Start): return []
    node_Visited = []
    priQueue = util.PriorityQueue()
    priQueue.push((node_Start, [], 0), 0)

    while not priQueue.isEmpty():

        node_Current, acts, prevCost = priQueue.pop()
        if node_Current not in node_Visited:
            node_Visited.append(node_Current)
            if problem.isGoalState(node_Current): return acts
            for nextNode, action, cost in problem.getSuccessors(node_Current):
                newAction = acts + [action]
                priority = prevCost + cost
                priQueue.push((nextNode, newAction, priority),priority)

    util.raiseNotDefined()

def nullHeuristic(state, problem=None): return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    node_Start = problem.getStartState()
    if problem.isGoalState(node_Start): return []
    node_Visited = []
    priQueue = util.PriorityQueue()
    priQueue.push((node_Start, [], 0), 0)

    while not priQueue.isEmpty():
        node_Current, acts, prevCost = priQueue.pop()
        if node_Current not in node_Visited:
            node_Visited.append(node_Current)
            if problem.isGoalState(node_Current): return acts
            for nextNode, action, cost in problem.getSuccessors(node_Current):
                newAction = acts + [action]
                newCostToNode = prevCost + cost
                heuristicCost = newCostToNode + heuristic(nextNode,problem)
                priQueue.push((nextNode, newAction, newCostToNode),heuristicCost)
                
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
